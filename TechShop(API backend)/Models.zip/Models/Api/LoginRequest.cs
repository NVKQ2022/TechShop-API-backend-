﻿namespace TechShop_API_backend_.Models.Api
{
    public class LoginRequest
    {
        public string? Username { get; set; }
        public string? Password { get; set; }
    }
}
