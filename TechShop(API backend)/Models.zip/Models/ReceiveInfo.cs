﻿namespace TechShop_API_backend_.Models
{
    public class ReceiveInfo
    {
        public string Name { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
    }

}
